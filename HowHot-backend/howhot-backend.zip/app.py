from fastapi import FastAPI, File, UploadFile
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from PIL import Image
import torch
from torchvision import models, transforms
from torchvision.models import ResNet18_Weights
from io import BytesIO
import traceback
import logging
import tempfile
import subprocess
import os

# Setup logging
logging.basicConfig(level=logging.INFO)

app = FastAPI()

@app.api_route("/", methods=["GET", "HEAD"])
def read_root():
    return {"message": "HowHot API is running!"}

@app.get("/ping")
def ping():
    return {"ping": "pong"}

# CORS setup
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Load model
model = models.resnet18(weights=None)
model.fc = torch.nn.Linear(model.fc.in_features, 6)

try:
    model.load_state_dict(torch.load("model/spice_model.pth", map_location=torch.device("cpu")))
    model.eval()
    logging.info("✅ Model loaded successfully.")
except Exception as e:
    logging.error(f"❌ Model failed to load: {e}")

# Image preprocessing
transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor()
])

def predict_spice(image: Image.Image):
    image = image.convert("RGB")
    image_tensor = transform(image).unsqueeze(0)
    with torch.no_grad():
        outputs = model(image_tensor)
        _, predicted = torch.max(outputs, 1)
    return predicted.item()

@app.post("/predict")
async def predict(file: UploadFile = File(...)):
    try:
        image_bytes = await file.read()
        filename = file.filename.lower()

        if filename.endswith(".heic"):
            # Save uploaded HEIC file to a temp file
            with tempfile.NamedTemporaryFile(delete=False, suffix=".heic") as tmp_heic:
                tmp_heic.write(image_bytes)
                tmp_heic_path = tmp_heic.name

            # Define JPEG output path
            tmp_jpeg_path = tmp_heic_path.replace(".heic", ".jpg")

            try:
                # Convert HEIC to JPEG using ffmpeg
                subprocess.run(
                    ["ffmpeg", "-y", "-i", tmp_heic_path, tmp_jpeg_path],
                    check=True,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                )
            except subprocess.CalledProcessError as ffmpeg_error:
                return JSONResponse(
                    status_code=415,
                    content={"detail": f"HEIC conversion failed: {ffmpeg_error.stderr.decode()}"}
                )
            finally:
                os.unlink(tmp_heic_path)  # Clean up the HEIC temp file

            # Open the converted JPEG for prediction
            try:
                with open(tmp_jpeg_path, "rb") as jpeg_file:
                    image = Image.open(jpeg_file).convert("RGB")
                os.unlink(tmp_jpeg_path)  # Clean up JPEG temp file
            except Exception as e:
                return JSONResponse(
                    status_code=500,
                    content={"detail": f"Failed to load converted JPEG: {str(e)}"}
                )

        else:
            # For JPG, PNG, etc.
            try:
                image = Image.open(BytesIO(image_bytes))
                image.verify()
                image = Image.open(BytesIO(image_bytes))
            except Exception as err:
                return JSONResponse(
                    status_code=415,
                    content={"detail": f"Unsupported or corrupted image: {err}"}
                )

        spice_level = predict_spice(image)
        return {"spice_level": spice_level}

    except Exception as e:
        traceback.print_exc()
        return JSONResponse(
            status_code=500,
            content={"detail": f"Image processing failed: {str(e)}"}
        )